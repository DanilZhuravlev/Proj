import stud
from statistics import mean

def calculate_averages(input_file_name, output_file_name):

    with open(input_file_name, mode='rt', newline='') as csv_in:
        stud_content = stud.reader(stud_in)
        with open(output_file_name, mode='wt', newline='') as csv_out:
            stud_writer = stud.writer(stud_out, delimiter=',')
            for row in stud_content:
                vals = [float(val) for val in row[1:]]
                stud_writer.writerow([row[0], mean(vals)])    

if __name__ == '__main__':
    calculate_averages('in.stud','out.stud')