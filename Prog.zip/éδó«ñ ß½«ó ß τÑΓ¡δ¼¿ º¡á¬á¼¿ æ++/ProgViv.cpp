#include <iostream>
#include <fstream>
#include <locale>
#include <vector>
#include <iterator>

using namespace std;

int main()
{ setlocale(0,"RUS");
    ifstream Fin("Schit.txt");
    ofstream Fout("Vivod.txt");
    int i=0;
    vector<string> a;
    if(Fin)
    {
        string slovo,mmn,mmx;
        while(!Fin.eof())
{
            Fin>>slovo;
            if(i==0)
                {
                mmx=slovo;mmn=slovo;
                }
            if(slovo.size()>=2)
            {
                    Fout<<slovo<<ends;

                    cout<<slovo<<ends;
                }
            if(slovo.size()<mmn.size()&&i!=0){mmn=slovo;}

            if(slovo.size()>mmx.size()&&i!=0){mmx=slovo;}

            if(slovo.size()%2==0) {a.push_back(slovo);}

            i++;
        }
        cout<<endl<<"Max Chislo - "<<mmx<<ends<<"Min Chislo - "<<mmn<<endl;

        Fout<<endl<<"Max Chislo - "<<mmx<<ends<<"Min Chislo - "<<mmn<<endl;

        cout<<endl<<"Vivod slov s chetnimi - ";

        Fout<<endl<<"Vivod slov s chetnimi - ";

        for(auto it=a.begin();it!=a.end();++it)
        {
            cout<<*it<<ends;

            Fout<<*it<<ends;
        }
    }
    else
        cout<<"Nelza otkrit file";
}
