#include <stdlib.h>
#include <time.h>
main()
{
srand(time(NULL));
int *a;
int k,n,i,j,temp,d;
printf("Chislo strok massiva\n");
scanf("%d",&n);
printf("Chislo stolbov massiva\n");
scanf("%d",&k);
a = (int*)malloc(n*k * sizeof(int));
int sum = 0, summax = 0,p;
for (i = 0; i<n; i++){
    for (j = 0; j < k; j++){
      printf("a[%d][%d] = ", i, j);
      scanf("%d", (a + i * k + j));
    }
  }
for(i = 0; i < n; i++) {
    sum = 0;
    for(j = 0; j < k; j++)
    {
        sum +=* (a + i * k + j);
    }
    if (sum >= summax) {summax = sum; p = i;}
    printf("\n sum=%d", sum);
}
printf ("\n");
printf ("Max summa v stroke %d;", p);
for (j = 0; j < k; j++){
      printf("%5d", *(a + p * k + j));
    }
    return 0;
}
