#include<windows.h>
#include <stdio.h>
#include <string.h>

struct patients {
 char familia [20];
 int vozrazt;
 char pol [10];
 int davlenie;
 };

 main() {
     struct patients st[20], temp;
     char strtemp [20],familia2 [20];
     int i;
     for (i = 0; i < 5; i++) {
         printf("Surname, Age, Male or Female, Pressure\n");
         scanf("%s%d%s%d", &st[i].familia, &st[i].vozrazt, &st[i].pol, &st[i].davlenie);
         printf("\n");
}
     printf("Patients with blood pressure above 140:\n");
             for (i = 0; i < 5; i++) {
                 if(st[i].davlenie > 140) {
                    printf("Surname, Age, Male or Female, Pressure\n");
                    printf("%s , %d , %s , %d \n", st[i].familia, st[i].vozrazt, st[i].pol, st[i].davlenie);
                    printf("\n");
                 }
}
             {
                 if(st[i].davlenie > 140) {
                    printf("Surname, Age, Male or Female, Pressure\n");
                    printf("%s , %d , %s , %d \n", st[i].familia, st[i].vozrazt, st[i].pol, st[i].davlenie);
                    printf("\n");
                 }
}
             printf("Type needed surname\n");
             scanf("%s",familia2);
             for (i = 0; i < 5; i++) {
                 if(strcmp(st[i].familia, familia2)==0) {
                        printf("\n");
                    printf("Surname, Age, Male or Female, Pressure\n");
                    printf("%s , %d , %s , %d \n", st[i].familia, st[i].vozrazt, st[i].pol, st[i].davlenie);
                    if(st[i].davlenie > 140)
                        printf("High pressure\n");
                    else
                        printf("Normal pressure\n");
                    printf("\n");
                    }
    }
    return 0;
}
